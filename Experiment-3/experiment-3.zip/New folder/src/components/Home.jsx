//export default function Home() {
 // return <h2>Home Page</h2>;}
function Home() {
  return (
    <div style={{ textAlign: "center", padding: "40px" }}>
      <h1>Welcome to My Website</h1>
      <p>This is the home page.</p>
      <button>Get Started</button>
    </div>
  );
}

export default Home;
